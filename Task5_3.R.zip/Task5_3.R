# Required
library(caret)
library(doParallel)

# Find how many cores are on your machine
detectCores() # Result = Typically 4 to 6

# Create Cluster with desired number of cores. Don't use them all! Your computer is running other processes. 
#cl <- makeCluster(6)
cl <- parallel::makeCluster(6, setup_strategy = "sequential")

# Register Cluster
registerDoParallel(cl)

# Confirm how many cores are now "assigned" to R and RStudio
getDoParWorkers() # Result 2 

#loading training data
df1 <- read.csv("galaxy_smallmatrix_labeled_9d.csv")
colnames(df1)

#Explore Data
library(plotly)
plot_ly(df1, x= ~df1$galaxysentiment, type='histogram')


library(corrplot)
M<-cor(df1)
head(round(M,2))

corrplot(M, method="circle")
corrplot(M, method="pie")
corrplot(M, method="color")
corrplot(M, type="upper")

# mat : is a matrix of data
# ... : further arguments to pass to the native R cor.test function
cor.mtest <- function(mat, ...) {
  mat <- as.matrix(mat)
  n <- ncol(mat)
  p.mat<- matrix(NA, n, n)
  diag(p.mat) <- 0
  for (i in 1:(n - 1)) {
    for (j in (i + 1):n) {
      tmp <- cor.test(mat[, i], mat[, j], ...)
      p.mat[i, j] <- p.mat[j, i] <- tmp$p.value
    }
  }
  colnames(p.mat) <- rownames(p.mat) <- colnames(mat)
  p.mat
}
# matrix of the p-value of the correlation
p.mat <- cor.mtest(mtcars)
head(p.mat[, 1:5])

options(max.print=1000000)

# Specialized the insignificant value according to the significant level
corrplot(M, type="upper", order="hclust", 
         p.mat = p.mat, sig.level = 0.01)

col <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", "#77AADD", "#4477AA"))
corrplot(M, method="color", col=col(200),  
         type="upper", order="hclust", 
         addCoef.col = "black", # Add coefficient of correlation
         tl.col="black", tl.srt=45, #Text label color and rotation
         # Combine with significance
         p.mat = p.mat, sig.level = 0.01, insig = "blank", 
         # hide correlation coefficient on the principal diagonal
         diag=FALSE 
)

# create a new data set and remove features highly correlated with the dependant 
dfCOR <- M
dfCOR$featureToRemove <- NULL

print(dfCOR)

#nearZeroVar() with saveMetrics = TRUE returns an object containing a table including: frequency ratio, percentage unique, zero variance and near zero variance n
nzvMetrics <- nearZeroVar(df1, saveMetrics = TRUE)
nzvMetrics

# nearZeroVar() with saveMetrics = FALSE returns an vector 
nzv <- nearZeroVar(df1, saveMetrics = FALSE) 
nzv

# create a new data set and remove near zero variance features
dfNZV <- df1[,-nzv]
str(dfNZV)

# Let's sample the data before using RFE
set.seed(123)
dfSample <- df1[sample(1:nrow(df1), 1000, replace=FALSE),]

# Set up rfeControl with randomforest, repeated cross validation and no updates
ctrl <- rfeControl(functions = rfFuncs, 
                   method = "repeatedcv",
                   repeats = 5,
                   verbose = FALSE)

# Use rfe and omit the response variable (attribute 59 iphonesentiment) 
rfeResults <- rfe(dfSample[,1:58], 
                  dfSample$galaxysentiment, 
                  sizes=(1:58), 
                  rfeControl=ctrl)

# Get results
rfeResults

# Plot results
plot(rfeResults, type=c("g", "o"))

# create new data set with rfe recommended features
dfRFE <- df1[,predictors(rfeResults)]

# add the dependent variable to iphoneRFE
dfRFE$galaxysentiment <- df1$galaxysentiment

# review outcome
str(dfRFE)

#New dataset for modeling
dfReq = dfRFE[c('iphone' ,'googleandroid', 'samsunggalaxy', 'iphoneperunc', 'iphoneperpos', 'galaxysentiment')]
dfReq

#Model Development - Sample Size
set.seed(220)
dfPar <- createDataPartition(dfReq$galaxysentiment, p = .70, list = FALSE )
training_df <- dfReq[dfPar, ]
testing_df <- dfReq[-dfPar, ]

#SVM
library("e1071")
attach(training_df)
x <- subset(training_df, select=-galaxysentiment)
y <- galaxysentiment

svm_model <- svm(galaxysentiment ~ ., data=training_df)
summary(svm_model)

#Run Predictions
pred <- predict(svm_model, x)
system.time(pred <- predict(svm_model, x))
plot   (x, y)

#Confuion Matrix Training Data 1
table(pred,y)

# SVM test:
x1 <- subset(testing_df, select=-galaxysentiment)
y1 <- galaxysentiment
pred2 <- predict(svm_model, x1)
system.time(pred2 <- predict(svm_model, x1))

#Confuion Matrix Test Data 2
cmRFSVM <- confusionMatrix(factor(pred2, levels=1:490), factor(y1, levels=1:490))
cmRFSVM
plot   (x1, y1)

#C5.0 Classification Models
set.seed(2411)
in_train <- sample(1:nrow(dfRFE), size = 3000)
train_data <- dfRFE[ in_train,]
test_data  <- dfRFE[-in_train,]

#Classification Trees
library(C50)
df_mod <- C5.0(x = train_data[, galaxysentiment], y = train_data$Status)
df_mod


#RandomForest
library(randomForest)
require(caTools)

dim(dfRFE)
head(dfRFE)
summary(dfRFE)
sapply(dfRFE, class)


aa




stopCluster(cl)
