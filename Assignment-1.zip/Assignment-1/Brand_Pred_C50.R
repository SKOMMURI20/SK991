library(caret)
library(data.table)
CompleteResponses <- fread("CompleteResponses.csv")
SurveyIncomplete <- fread("SurveyIncomplete.csv")
str(CompleteResponses)
cresponse1 <- CompleteResponses
nrow(cresponse1)
#Check if the data has any missing values
sum(is.na(cresponse1))

#Spliting data using caret
#define an 75%/25% train/test split of dataset
set.seed(123)
inTrain <- createDataPartition(cresponse1$brand, p=.75, list=FALSE)
training <- cresponse1[inTrain,]
testing <- cresponse1[-inTrain,]
training
testing
nrow(training)
nrow(testing)

#10 fold cross validation and training
fitcontrol <- trainControl(method = "repeatedcv", number=10, repeats = 1)
metric <- "Accuracy"
#grid <-   expand.grid( .winnow = c(TRUE,FALSE), .trials=c(1,5,10,15,20), .model="tree" )
rfFit4 <- train(factor(brand) ~ ., data=training, method = "C5.0", metric=metric, trControl=fitcontrol)

#Variable Importance
varImp(object=rfFit4)
#plotting Variable importance for C5.0
plot(varImp(object=rfFit4), main="RF -Variable Importance")

summary(rfFit4)

SIncomplete$brand <- predict(rfFit4, SIncomplete)
summary(SIncomplete)


write.csv(SIncomplete, "SurveyComplete1.csv", row.names = TRUE)
