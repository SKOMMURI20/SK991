#Author: Sathish Kommuri , R-Task2
str(CompleteResponses)
cresponse1 <- CompleteResponses

#Check if the data has any missing values
sum(is.na(cresponse1))

#Spliting data using caret
#define an 75%/25% train/test split of dataset
set.seed(123)
inTrain <- createDataPartition(cresponse1$brand, p=.75, list=FALSE)
training <- cresponse1[inTrain,]
testing <- cresponse1[-inTrain,]
training
testing
nrow(training)
nrow(testing)

#10 fold cross validation
fitcontrol <- trainControl(method = "repeatedcv", number=10, repeats = 1)

#train Random Forest Regresson Model with a Tunelength =1, Train with 1 mtry value for randomforest
system.time(rfFit1 <- train(brand~., data=training, method = "rf", trControl=fitcontrol, TRUE))
rfFit1

#Variable Importance
varImp(object=rfFit1)
#plotting Variable importance for Random Forest
plot(varimp(object=rfFit), main="RF -Variable Importance")

summary(rfFit1)

rfprediction<-predict(rfFit1,testing)
rfprediction

summary(rfprediction)

postResample(pred = rfprediction, obs = testing$brand)

SIncomplete <- SurveyIncomplete
str(SIncomplete)
SIncomplete$brand <- as.factor(SIncomplete$brand)

SIncomplete$brand <- predict(rfFit1, SIncomplete)
SIrfprediction
summary(SIrfprediction)

SIncomplete$brandP <- c(SIrfprediction)
str(SIncomplete)

write.csv(SIncomplete, "SurveyComplete1.csv", row.names = TRUE)

