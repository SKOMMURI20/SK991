#Author: Sathish Kommuri, R Task 2 c50
str(CompleteResponses)
cresponse2 <- CompleteResponses
cresponse2brand <- as.factor(cresponse2$brand)
set.seed(123)
trainSize <- round(nrow(cresponse2)* 0.75)
testSize <- nrow(cresponse2) - trainSize
trainSize
testSize
training_indices<-sample(seq_len(nrow(cresponse2)),size =trainSize)
trainSet <- Cresponse2[training_indices, ]
testSet <- Cresponse2[-training_indices, ]

c5fit1 <- c5.0(brand ~ ., trainSet, rules = TRUE, trial=10)
c5fit1
summary(c5fit1)

varImp(object=c5fit1)
plot(varImp(object=c5fit1), main="c5.0 - variable Importance")

prediction<-predict(c5fit1, testSet)
prediction
summary(prediction)

postResample(pred = prediction, obs= testSet$brand)

corrsurvery <- cor(CompleteResponses)
corrsurvery
corrplot(corrsurvery)