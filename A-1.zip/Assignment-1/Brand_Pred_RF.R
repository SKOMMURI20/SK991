#Author: Sathish Kommuri , R-Task2
library(caret)
library(data.table)
CompleteResponses <- fread("CompleteResponses.csv")
SurveyIncomplete <- fread("SurveyIncomplete.csv")
str(CompleteResponses)
cresponse1 <- CompleteResponses
nrow(cresponse1)
#Check if the data has any missing values
sum(is.na(cresponse1))

#Spliting data using caret
#define an 75%/25% train/test split of dataset
set.seed(123)
inTrain <- createDataPartition(cresponse1$brand, p=.75, list=FALSE)
training <- cresponse1[inTrain,]
testing <- cresponse1[-inTrain,]
training
testing
nrow(training)
nrow(testing)

#10 fold cross validation
fitcontrol <- trainControl(method = "repeatedcv", number=10, repeats = 1)

#train Random Forest Regresson Model with mtry values 2,3,4,5,6
metric <- "Accuracy"
grid <- data.frame(mtry = c(2,3,4,5,6))
rfFit1 <- train(factor(brand) ~ ., data=training, method = "rf", metric=metric, trControl=fitcontrol, tuneGrid = grid, ntree=200)

#Variable Importance
varImp(object=rfFit1)
#plotting Variable importance for Random Forest
plot(varImp(object=rfFit1), main="RF -Variable Importance")
summary(rfFit1)

#execution with incomplete dataset
SIncomplete$brand <- predict(rfFit1, SIncomplete)
summary(SIncomplete)

write.csv(SIncomplete, "SurveyComplete1.csv", row.names = TRUE)
